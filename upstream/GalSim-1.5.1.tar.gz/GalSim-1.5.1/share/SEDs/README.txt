A few SEDs for use with GalSim ChromaticObjects.

vega.txt is derived from HST CALSPEC data.

CWW_* files are from Coleman, Wu, and Weedman (1980).
See comments at top of files and the script at
$GALSIM_DIR/devel/getSEDs.py for more details.
