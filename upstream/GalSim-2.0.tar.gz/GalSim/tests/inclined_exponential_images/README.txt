The images in this folder were calculated using code supplied by Lance Miller, which is contained
in the file "hankelcode.c" (with some modifications by Bryan Gillis to make it suitable for
generating comparison galaxies).

hankelcode.c compiles to a stand-alone C program, which depends on the libraries FFTW and CFITSIO.