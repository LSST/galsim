Surface Operators
=================

.. autoclass:: galsim.WavelengthSampler
    :members:

.. autoclass:: galsim.FRatioAngles
    :members:

.. autoclass:: galsim.PhotonDCR
    :members:

