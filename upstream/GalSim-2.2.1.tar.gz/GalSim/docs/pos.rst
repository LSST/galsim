Positions
=========

.. autoclass:: galsim.Position
    :members:

.. autoclass:: galsim.PositionI
    :members:
    :show-inheritance:

.. autoclass:: galsim.PositionD
    :members:
    :show-inheritance:
