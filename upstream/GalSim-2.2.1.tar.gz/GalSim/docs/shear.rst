
The Shear class
===============

.. autoclass:: galsim.Shear
    :members:

.. autofunction:: galsim._Shear

