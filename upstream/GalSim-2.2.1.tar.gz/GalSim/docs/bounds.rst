Bounding boxes
==============

.. autoclass:: galsim.Bounds
    :members:

.. autoclass:: galsim.BoundsI
    :members:
    :show-inheritance:

.. autoclass:: galsim.BoundsD
    :members:
    :show-inheritance:

.. autofunction:: galsim._BoundsI

.. autofunction:: galsim._BoundsD

