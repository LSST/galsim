Lookup Tables
=============

.. autoclass:: galsim.LookupTable
    :members:

    .. automethod:: galsim.LookupTable.__call__

.. autoclass:: galsim.LookupTable2D
    :members:

    .. automethod:: galsim.LookupTable2D.__call__

.. autofunction:: galsim.table._LookupTable2D
