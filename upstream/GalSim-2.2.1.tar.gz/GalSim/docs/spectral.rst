
Spectral Correlated Noise
=========================

.. autoclass:: galsim.CovarianceSpectrum
    :members:
