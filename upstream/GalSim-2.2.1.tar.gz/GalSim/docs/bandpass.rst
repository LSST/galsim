Bandpass Filters
================

.. autoclass:: galsim.Bandpass
    :members:

    .. automethod:: galsim.Bandpass.__call__
