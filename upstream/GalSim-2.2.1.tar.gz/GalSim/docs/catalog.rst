Catalogs and Input Dictionaries
===============================

.. autoclass:: galsim.Catalog
    :members:

.. autoclass:: galsim.OutputCatalog
    :members:

.. autoclass:: galsim.Dict
    :members:


