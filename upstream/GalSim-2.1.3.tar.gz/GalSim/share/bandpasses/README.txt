A few Bandpasses for use with GalSim ChromaticObjects.

See comments at the top of files and the scripts at

$GALSIM_DIR/devel/getLSSTBandpass.py
$GALSIM_DIR/devel/getACSBandpass.py
$GALSIM_DIR/devel/getWFC3Bandpass.py

for more details.
