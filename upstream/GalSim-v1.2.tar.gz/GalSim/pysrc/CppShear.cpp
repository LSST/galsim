/* -*- c++ -*-
 * Copyright (c) 2012-2014 by the GalSim developers team on GitHub
 * https://github.com/GalSim-developers
 *
 * This file is part of GalSim: The modular galaxy image simulation toolkit.
 * https://github.com/GalSim-developers/GalSim
 *
 * GalSim is free software: redistribution and use in source and binary forms,
 * with or without modification, are permitted provided that the following
 * conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice, this
 *    list of conditions, and the disclaimer given in the accompanying LICENSE
 *    file.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions, and the disclaimer given in the documentation
 *    and/or other materials provided with the distribution.
 */
#ifndef __INTEL_COMPILER
#if defined(__GNUC__) && __GNUC__ >= 4 && (__GNUC__ >= 5 || __GNUC_MINOR__ >= 8)
#pragma GCC diagnostic ignored "-Wunused-local-typedefs"
#endif
#endif

#define BOOST_NO_CXX11_SMART_PTR
#include "boost/python.hpp"
#include "CppShear.h"
#include "NumpyHelper.h"

namespace bp = boost::python;

namespace galsim {
namespace {

struct PyCppShear {

    static bp::handle<> getMatrix(const CppShear& self) {
        static npy_intp dim[2] = {2, 2};
        // Because the C++ version sets references that are passed in, and that's not possible in
        // Python, we wrap this instead, which returns a numpy array.
        double a=0., b=0., c=0.;
        self.getMatrix(a, b, c);
        double ar[4] = { a, c, c, b };
        PyObject* r = PyArray_SimpleNewFromData(2, dim, NPY_DOUBLE, ar);
        if (!r) throw bp::error_already_set();
        PyObject* r2 = PyArray_FROM_OF(r, NPY_ARRAY_ENSURECOPY);
        Py_DECREF(r);
        return bp::handle<>(r2);
    }

    static void wrap() {
        static const char* doc = 
            "CppShear is represented internally by e1 and e2, which are the second-moment\n"
            "definitions: ellipse with axes a & b has e=(a^2-b^2)/(a^2+b^2).\n"
            "But can get/set the ellipticity by other measures:\n"
            "g (default constructor) is \"reduced shear\" such that g=(a-b)/(a+b)\n"
            "eta is \"conformal shear\" such that a/b = exp(eta).\n"
            "The constructor takes g1/g2 (reduced shear) only.\n"
            "Beta is always the real-space position angle of major axis.\n"
            "e.g., g1 = g cos(2*Beta), g2 = g sin(2*Beta).\n"
            "\n"
            "The + and - operators for CppShear are overloaded to do\n"
            "Composition: returns ellipticity of\n"
            "circle that is sheared first by RHS and then by\n"
            "LHS CppShear.  Note that this addition is\n"
            "***not commutative***!\n"
            "In the += and -= operations, self is LHS\n"
            "and the operand is RHS of + or - .\n"
            ;
            

        bp::class_<CppShear>("_CppShear", doc, bp::init<const CppShear &>())
            .def(bp::init<double,double>((bp::arg("g1")=0.,bp::arg("g2")=0.)))
            .def("setE1E2", &CppShear::setE1E2, (bp::arg("e1")=0.,bp::arg("e2")=0.),
                 bp::return_self<>())
            .def("setEBeta", &CppShear::setEBeta, (bp::arg("e")=0.,bp::arg("beta")=0.),
                 bp::return_self<>())
            .def("setEta1Eta2", &CppShear::setEta1Eta2, (bp::arg("eta1")=0.,bp::arg("eta2")=0.),
                 bp::return_self<>())
            .def("setEtaBeta", &CppShear::setEtaBeta, (bp::arg("eta")=0.,bp::arg("beta")=0.),
                 bp::return_self<>())
            .def("setG1G2", &CppShear::setG1G2, (bp::arg("g1")=0.,bp::arg("g2")=0.),
                 bp::return_self<>())
            .def("getE1", &CppShear::getE1)
            .def("getE2", &CppShear::getE2)
            .def("getE", &CppShear::getE)
            .def("getESq", &CppShear::getESq)
            .def("getBeta", &CppShear::getBeta)
            .def("getEta", &CppShear::getEta)
            .def("getG", &CppShear::getG)
            .def("getG1", &CppShear::getG1)
            .def("getG2", &CppShear::getG2)
            .def(-bp::self)
            .def(bp::self + bp::self)
            .def(bp::self - bp::self)
            .def(bp::self += bp::self)
            .def(bp::self -= bp::self)
            .def(
                "rotationWith", &CppShear::rotationWith, bp::args("rhs"),
                "Give the rotation angle for self+rhs;\n"
                "the s1 + s2 operation on points in\n"
                "the plane induces a rotation as well as a shear.\n"
                "This tells you what the rotation was for LHS+RHS.\n"
            )
            .def(bp::self == bp::self)
            .def(bp::self != bp::self)
            .def(str(bp::self))
            .def("getMatrix", getMatrix)
            ;
    }

};

} // anonymous

void pyExportCppShear() {
    PyCppShear::wrap();
}

} // namespace galsim
