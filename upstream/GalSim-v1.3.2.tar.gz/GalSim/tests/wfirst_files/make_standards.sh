# Shell script used by Rachel to generate the standards for comparison in this directory.
# Note: this script makes files for all SCAs, so it's a lot of files.
# We will just use SCAs 2, 13, 7, and 18 for tests 1, 2, 3, and 4 respectively.
/Users/rmandelb/great3/wfirst/wcs/new/wfi_wcs_gen_0.4 -f 127.0 -70.0 160.0 /great3/wfirst/wcs/sip_422.txt /git/GalSim/tests/wfirst_files/test1_
/Users/rmandelb/great3/wfirst/wcs/new/wfi_wcs_gen_0.4 307.4 50.0 79.0 /great3/wfirst/wcs/sip_422.txt /git/GalSim/tests/wfirst_files/test2_
/Users/rmandelb/great3/wfirst/wcs/new/wfi_wcs_gen_0.4 -f -61.52 22.7 23.4 /great3/wfirst/wcs/sip_422.txt /git/GalSim/tests/wfirst_files/test3_
/Users/rmandelb/great3/wfirst/wcs/new/wfi_wcs_gen_0.4 0.0 0.0 -3.1 /great3/wfirst/wcs/sip_422.txt /git/GalSim/tests/wfirst_files/test4_
